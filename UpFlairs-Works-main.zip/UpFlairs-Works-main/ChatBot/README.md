##  to execute this application 
1. clone this repository 
2. install dependency 
3. execute gemini_vision.py file 

### to install dependency 
pip install requirements.txt 

## to execute this application 
streamlit run gemini_vision.py 


Thank you 😎😎